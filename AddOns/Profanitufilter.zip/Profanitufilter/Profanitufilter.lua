local function Event(event, handler)
    if _G.event == nil then
        _G.event = CreateFrame('Frame')
        _G.event.handler = {}
        _G.event.OnEvent = function(frame, event, ...)
            for key, handler in pairs(_G.event.handler[event]) do
                handler(...)
            end
        end
        _G.event:SetScript('OnEvent', _G.event.OnEvent)
    end
    if _G.event.handler[event] == nil then
        _G.event.handler[event] = {}
        _G.event:RegisterEvent(event)
    end
    table.insert(_G.event.handler[event], handler)
end

Event(
    'PLAYER_ENTERING_WORLD',
    function()
        if not word then
            word = {}
        end
    end
)

local function CreateUIFrames()
    if MainFrame ~= nil then
        MainFrame:Show()
        return
    end
    MainFrame = CreateFrame('Frame', 'reportcd', UIParent, 'PortraitFrameTemplate')
    MainFrame:SetFrameStrata('DIALOG')
    MainFrame:SetWidth(500)
    MainFrame:SetHeight(400)
    MainFrame:SetPoint('CENTER', UIParent)
    MainFrame:SetMovable(true)
    MainFrame:EnableMouse(true)
    MainFrame:RegisterForDrag('LeftButton', 'RightButton')
    MainFrame:SetClampedToScreen(true)
    MainFrame.title = _G['reportcdTitleText']
    MainFrame.title:SetText('主动过滤')
    MainFrame:SetScript(
        'OnMouseDown',
        function(self)
            self:StartMoving()
            self.isMoving = true
        end
    )

    MainFrame:SetScript(
        'OnMouseUp',
        function(self)
            if self.isMoving then
                self:StopMovingOrSizing()
                self.isMoving = false
            end
        end
    )

    local icon = MainFrame:CreateTexture('$parentIcon', 'OVERLAY', nil, -8)
    --图标
    icon:SetSize(60, 60)
    icon:SetPoint('TOPLEFT', -5, 7)
    icon:SetTexture('Interface\\FriendsFrame\\Battlenet-Portrait')
    --标题
    Text = MainFrame:CreateFontString('FontString', 'OVERLAY', 'GameFontNormalLarge')
    Text:SetPoint('TOPLEFT', MainFrame, 'TOPLEFT', 20, -25)
    Text:SetWidth(200)
    Text:SetText('反和谐设置')

    --添加spellID
    tipText = reportcd:CreateFontString('FontString', 'OVERLAY', 'GameFontNormalLarge')
    tipText:SetPoint('TOPLEFT', MainFrame, 'TOPLEFT', 10, -100)
    tipText:SetWidth(200)
    tipText:SetText('添加需要反和谐的文字')

    Button = CreateFrame('EditBox', 'reportcdaddspellid', MainFrame, 'InputBoxTemplate')
    Button:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 40, -90)
    Button:SetWidth(150)
    Button:SetHeight(20)
    Button:SetAutoFocus(false)
    Button:SetText('')

    --替换为
    tipText = reportcd:CreateFontString('FontString', 'OVERLAY', 'GameFontNormalLarge')
    tipText:SetPoint('TOPLEFT', MainFrame, 'TOPLEFT', 200, -100)
    tipText:SetWidth(200)
    tipText:SetText('替换为')

    Button = CreateFrame('EditBox', 'reportcdchaspellid', MainFrame, 'InputBoxTemplate')
    Button:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 230, -90)
    Button:SetWidth(150)
    Button:SetHeight(20)
    Button:SetAutoFocus(false)
    Button:SetText('')

    --添加
    Button = CreateFrame('Button', 'reportcdcleanall', MainFrame, 'UIPanelButtonTemplate')
    Button:SetSize(50, 30)
    Button:SetNormalFontObject('GameFontNormalSmall')
    Button:SetText('确认')
    Button:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 400, -90)
    Button:SetScript(
        'OnClick',
        function(self)
            word[reportcdaddspellid:GetText()] = reportcdchaspellid:GetText()
        end
    )

    --筛选
    tipText = reportcd:CreateFontString('FontString', 'OVERLAY', 'GameFontNormalLarge')
    tipText:SetPoint('TOPLEFT', MainFrame, 'TOPLEFT', 10, -180)
    tipText:SetWidth(200)
    tipText:SetText('筛选关键词')

    Button = CreateFrame('EditBox', 'reportcdchaselect', MainFrame, 'InputBoxTemplate')
    Button:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 40, -180)
    Button:SetWidth(150)
    Button:SetHeight(20)
    Button:SetAutoFocus(false)
    Button:SetText('')

    --下拉菜单
    CreateFrame('Button', 'reportcddropdownlist', MainFrame, 'UIDropDownMenuTemplate')
    reportcddropdownlist:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 200, -180)
    local tempformat = 0
    local function reportcddropdownlist_OnClick(self, arg1, arg2, checked)
        -- Update temp variable
        tempformat = arg1
        -- Update dropdownmenu text
        UIDropDownMenu_SetText(reportcddropdownlist, tempformat)
    end
    local function reportcddropdownlist_Initialize(self, level)
        local info = UIDropDownMenu_CreateInfo()
        info.func = reportcddropdownlist_OnClick
        for i, v in pairs(word) do
            if i:find(reportcdchaselect:GetText()) then
                info.arg1, info.text = i, i .. ' = ' .. v
                UIDropDownMenu_AddButton(info)
            end
        end
    end
    UIDropDownMenu_Initialize(reportcddropdownlist, reportcddropdownlist_Initialize)
    UIDropDownMenu_SetWidth(reportcddropdownlist, 148)
    UIDropDownMenu_SetButtonWidth(reportcddropdownlist, 124)
    UIDropDownMenu_SetText(reportcddropdownlist, '移除')
    UIDropDownMenu_JustifyText(reportcddropdownlist, 'LEFT')
    --清除spellid
    Button = CreateFrame('Button', 'reportcdclean', MainFrame, 'UIPanelButtonTemplate')
    Button:SetSize(50, 30)
    Button:SetNormalFontObject('GameFontNormalSmall')
    Button:SetText('清除')
    Button:SetPoint('TOPLEFT', Text, 'BOTTOMLEFT', 400, -190)
    Button:SetScript(
        'OnClick',
        function(self)
            if tempformat ~= 0 then
                word[UIDropDownMenu_GetText(reportcddropdownlist, tempformat)] = nil
                UIDropDownMenu_SetText(reportcddropdownlist, '移除黑名单')
            end
        end
    )
    --显示窗口
    MainFrame:Show()
end

local profaniturfilter = SendChatMessage

local lastmessage = ''

function SendChatMessage(msg, ...)
    for i in pairs(word) do
        msg = msg:gsub(i, word[i])
    end
    lastmessage = msg
    profaniturfilter(msg, ...)
end

local localpalyer, localrealm, playerfullname

local function StringToTable(s)
    local tb = {}
    for utfChar in string.gmatch(s, '.') do
        table.insert(tb, utfChar)
    end
    return tb
end

local function addspace(msg)
    N_msg = ''
    i = 1
    while true do
        c = string.sub(msg, i, i)
        b = string.byte(c)
        while b == 124 do
            if
                string.sub(msg, i + 1, i + 1) == 'c' or string.sub(msg, i + 1, i + 7) == 'Hplayer' or
                    string.sub(msg, i + 1, i + 10) == 'Tinterface'
             then
                _, pos = string.find(string.sub(msg, i), '|r', i + 1)
                N_msg = N_msg .. string.sub(msg, i, pos + 1)
                i = pos + 2
                if i > #msg then
                    break
                end
                c = string.sub(msg, i, i)
                b = string.byte(c)
            else
                N_msg = N_msg .. '|·'
                i = i + 1
                c = string.sub(msg, i, i)
                b = string.byte(c)
                break
            end
        end
        if i > #msg then
            break
        end
        if b > 128 then
            N_msg = N_msg .. string.sub(msg, i, i + 2) .. ' '
            i = i + 3
        else
            if b == 32 then
                N_msg = N_msg .. ' '
            else
                N_msg = N_msg .. c .. ' '
            end
            i = i + 1
        end

        if i > #msg then
            break
        end
    end
    return N_msg
end
local function addtoword(s)
    word[s] = addspace(s)
    print('已添加：' .. s .. '=' .. word[s])
end
local a = {}
local b = {}
local first = 0
local last = 0
local strLength = 0
local readyaddtoword = ''

local psfilter = function(_, event, msg, player, ...)
    if player ~= playerfullname then
        return false
    end
    if msg:find('|r') or msg:find('|R') or msg:find('|H') or msg:find('|h') then
        return false
    end
    if msg ~= lastmessage then
        print('检测到屏蔽词,尝试定位')
        a = StringToTable(lastmessage)
        b = StringToTable(msg)
        strLength = #b
        for i = 0, strLength, 1 do
            if (a[i] ~= b[i]) then
                first = i
                break
            end
        end
        a = StringToTable(string.reverse(lastmessage))
        b = StringToTable(string.reverse(msg))
        for i = 0, strLength, 1 do
            if (a[i] ~= b[i]) then
                last = i
                break
            end
        end
        readyaddtoword = string.sub(lastmessage, first, -last)
        addtoword(readyaddtoword)
        return false, lastmessage, player, ...
    end
end

--过滤频道
local function ADDfilter()
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_INLINE_TOAST_ALERT', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_INLINE_TOAST_BROADCAST', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_INLINE_TOAST_BROADCAST_INFORM', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_INLINE_TOAST_CONVERSATION', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_WHISPER', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_WHISPER_INFORM', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_BN_WHISPER_PLAYER_OFFLINE', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_COMMUNITIES_CHANNEL', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_CURRENCY', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_EMOTE', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_FILTERED', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_GUILD', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_GUILD_ACHIEVEMENT', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_GUILD_ITEM_LOOTED', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_IGNORED', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_INSTANCE_CHAT', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_INSTANCE_CHAT_LEADER', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_PARTY', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_PARTY_LEADER', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_RAID', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_RAID_LEADER', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_RAID_WARNING', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_RESTRICTED', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_SAY', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_SKILL', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_SYSTEM', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_TARGETICONS', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_TEXT_EMOTE', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_TRADESKILLS', psfilter)
    ChatFrame_AddMessageEventFilter('CHAT_MSG_YELL', psfilter)
end

--玩家登陆事件
Event(
    'PLAYER_LOGIN',
    function()
        ADDfilter() --添加频道
        localpalyer, localrealm = UnitFullName('player', true)
        playerfullname = localpalyer .. '-' .. localrealm
    end
)

SLASH_profaniturfilter1 = '/pff'

SlashCmdList.profaniturfilter = function()
    CreateUIFrames()
end
